package com.example.android.sunshine;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by Oluleke on 15/03/2017.
 */

public class ShowUserProfile extends AppCompatActivity {
}
