/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.example.android.sunshine;

import android.content.Context;
import android.net.Uri;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.net.URI;
import java.net.URISyntaxException;

/**
 * {@link ForecastAdapter} exposes a list of weather forecasts to a
 * {@link android.support.v7.widget.RecyclerView}
 */
public class ForecastAdapter extends RecyclerView.Adapter<ForecastAdapter.ForecastAdapterViewHolder> {

    //private String[] mWeatherData;
    private String[] mGitHubData;

    /*
     * An on-click handler that we've defined to make it easy for an Activity to interface with
     * our RecyclerView
     */
    private final ForecastAdapterOnClickHandler mClickHandler;

    /**
     * The interface that receives onClick messages.
     */
    public interface ForecastAdapterOnClickHandler {
        void onClick(String currentGitHubUser);
    }

    /**
     * Creates a ForecastAdapter.
     *
     * @param clickHandler The on-click handler for this adapter. This single handler is called
     *                     when an item is clicked.
     */
    public ForecastAdapter(ForecastAdapterOnClickHandler clickHandler) {
        mClickHandler = clickHandler;
    }

    /**
     * Cache of the children views for a forecast list item.
     */
    public class ForecastAdapterViewHolder extends RecyclerView.ViewHolder implements OnClickListener {
        public final TextView mTextShareUserName;
//        public final TextView mTextProfilePhoto;
//        public final TextView mTextProfileURL;
        public final TextView mTextUserName;

        public final ImageView mImageView;

        public ForecastAdapterViewHolder(View view) {
            super(view);
            mTextUserName = (TextView) view.findViewById(R.id.tv_userName);
            mImageView = (ImageView)view.findViewById(R.id.iv_userImage);
            mTextShareUserName = (TextView) view.findViewById(R.id.tv_gitUserName);
//            mTextProfilePhoto = (TextView) view.findViewById(R.id.tv_profilePhoto);
//            mTextProfileURL = (TextView) view.findViewById(R.id.tv_profileURL);

                      view.setOnClickListener(this);
        }

        /**
         * This gets called by the child views during a click.
         *
         * @param v The View that was clicked
         */
        @Override
        public void onClick(View v) {
            int adapterPosition = getAdapterPosition();
            String currentGitHubUser = mGitHubData[adapterPosition];
            mClickHandler.onClick(currentGitHubUser);
        }
    }

    /**
     * This gets called when each new ViewHolder is created. This happens when the RecyclerView
     * is laid out. Enough ViewHolders will be created to fill the screen and allow for scrolling.
     *
     * @param viewGroup The ViewGroup that these ViewHolders are contained within.
     * @param viewType  If your RecyclerView has more than one type of item (which ours doesn't) you
     *                  can use this viewType integer to provide a different layout. See
     *                  {@link android.support.v7.widget.RecyclerView.Adapter#getItemViewType(int)}
     *                  for more details.
     * @return A new ForecastAdapterViewHolder that holds the View for each list item
     */
    @Override
    public ForecastAdapterViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        Context context = viewGroup.getContext();
        int layoutIdForListItem = R.layout.forecast_list_item;
        LayoutInflater inflater = LayoutInflater.from(context);
        boolean shouldAttachToParentImmediately = false;

        View view = inflater.inflate(layoutIdForListItem, viewGroup, shouldAttachToParentImmediately);
        return new ForecastAdapterViewHolder(view);
    }

    /**
     * OnBindViewHolder is called by the RecyclerView to display the data at the specified
     * position. In this method, we update the contents of the ViewHolder to display the weather
     * details for this particular position, using the "position" argument that is conveniently
     * passed into us.
     *
     * @param forecastAdapterViewHolder The ViewHolder which should be updated to represent the
     *                                  contents of the item at the given position in the data set.
     * @param position                  The position of the item within the adapter's data set.
     */
    @Override
    public void onBindViewHolder(ForecastAdapterViewHolder forecastAdapterViewHolder, int position) {
        String currentUserData = mGitHubData[position];

        String [] currentUserDataArray  = currentUserData.split("<>");
        /*.*/
        /**
         * currentUserDataArray [] :
         * This array contains 5 elements [login ^ avatar_url ^ html_url ^ userId ^ url] in that order.
         */
        //Set Username

        //Convert url text to URIs
        Uri avatarUri = Uri.parse(currentUserDataArray[1]);
        //Uri profileUri = Uri.parse(currentUserDataArray[2]);

        //Assign values

//        forecastAdapterViewHolder.mTextShareUserName.setText(currentUserDataArray[0]);
//        forecastAdapterViewHolder.mTextProfilePhoto.setText(currentUserDataArray[1]);
//        forecastAdapterViewHolder.mTextProfileURL.setText(currentUserDataArray[2]);

        //forecastAdapterViewHolder.mImageView.setImageURI(avatarUri);//Set ImageView to Avatar
        forecastAdapterViewHolder.mTextUserName.setText(currentUserDataArray[0]);//Set Username
//



    }

    /**
     * This method simply returns the number of items to display. It is used behind the scenes
     * to help layout our Views and for animations.
     *
     * @return The number of items available in our forecast
     */
    @Override
    public int getItemCount() {
        if (null == mGitHubData) return 0;
        return mGitHubData.length;
    }

    /**
     * This method is used to set the weather forecast on a ForecastAdapter if we've already
     * created one. This is handy when we get new data from the web but don't want to create a
     * new ForecastAdapter to display it.
     *
     * @param weatherData The new weather data to be displayed.
     */
//    public void setWeatherData(String[] weatherData) {
//        mWeatherData = weatherData;
//        notifyDataSetChanged();
//    }
    /**
     * @param gitHubData The new weather data to be displayed.
     */
    public void setGitHubData(String[] gitHubData) {
        mGitHubData = gitHubData;
        notifyDataSetChanged();
    }
}