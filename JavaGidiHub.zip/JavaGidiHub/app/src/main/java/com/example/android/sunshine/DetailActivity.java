package com.example.android.sunshine;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.ShareCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.net.MalformedURLException;
import java.net.URL;

//public class DetailActivity extends AppCompatActivity implements
//        ForecastAdapter.ForecastAdapterOnClickHandler {
    public class DetailActivity extends AppCompatActivity {
    private String mGitHubUser;
    private TextView mgitUserName ;
    private TextView mTextProfileURL ;
    private TextView mTextProfilePhoto;
    private ImageView mImageUserPhoto;

    private String UserName ;
    private String ProfileURL ;
    private String ProfilePhoto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        mgitUserName = (TextView) findViewById(R.id.tv_gitUserName);
        mTextProfileURL = (TextView) findViewById(R.id.tv_gitProfileURL);
        mTextProfilePhoto = (TextView) findViewById(R.id.tv_gitProfilePhoto);
        mImageUserPhoto = (ImageView)findViewById(R.id.iv_userImage);

        Intent intentThatStartedThisActivity = getIntent();

        if (intentThatStartedThisActivity != null) {
            if (intentThatStartedThisActivity.hasExtra(Intent.EXTRA_TEXT)) {
                mGitHubUser = intentThatStartedThisActivity.getStringExtra(Intent.EXTRA_TEXT);

                UserName = mGitHubUser.split("<>")[0];
                ProfilePhoto = mGitHubUser.split("<>")[1];
                ProfileURL= mGitHubUser.split("<>")[2];

                mgitUserName.setText("Username :" + UserName);//Set Username
                mTextProfilePhoto.setText(ProfilePhoto);//Set UserPhoto
                mTextProfileURL.setText("Profile Url : " + ProfileURL);//Set UserProfileURL

                if (!ProfilePhoto.isEmpty()){
                    //load Image
                    //mImageUserPhoto.setImageURI(Uri.parse(ProfilePhoto));
//                    URL url = null;
//                    try {
//                        url = new URL(ProfilePhoto);
//                        Bitmap bmp = BitmapFactory.decodeStream(url.openConnection().getInputStream());
//                        mImageUserPhoto.setImageBitmap(bmp);
//                    } catch (Exception e) {
//                        e.printStackTrace();
//                    }

                }
                //mTextProfileURL.setOnClickListener(this.mTextProfileURL.get);
                //mTextProfileURL.setOnClickListener(View.OnClickListener().new){

                //}
            }
        }
    }

    /**
     * Uses the ShareCompat Intent builder to create our Forecast intent for sharing. We set the
     * type of content that we are sharing (just regular text), the text itself, and we return the
     * newly created Intent.
     *
     * @return The Intent to use to start our share.
     */

    public void DisplayUrlProfile (View v){
          try {
            Intent i = new Intent(Intent.ACTION_VIEW);
              i.setData(Uri.parse(mGitHubUser.split("<>")[2]));
            startActivity(i);
        }catch(Exception e){
            e.printStackTrace();
        }

    }



    private Intent createShareForecastIntent() {
        Intent shareIntent = ShareCompat.IntentBuilder.from(this)
                .setType("text/plain")
                .setText("Check out this awesome Developer @" + UserName+ ","
                        + ProfileURL )
                .getIntent();
        return shareIntent;
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.detail, menu);
        MenuItem menuItem = menu.findItem(R.id.action_share);
        menuItem.setIntent(createShareForecastIntent());
        return true;
    }
}